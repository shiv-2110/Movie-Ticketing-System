package com.example.movieticketing.movieticketingsystem.models;

public class Movie {
	String title;
	String genre;
	double ticketPrice;
	String type; // silver, plat, diamond
	
	public Movie(String title, String genre, double ticketPrice, String type) {
		super();
		this.title = title;
		this.genre = genre;
		this.ticketPrice = ticketPrice;
		this.type = type;
	}
	
	

}

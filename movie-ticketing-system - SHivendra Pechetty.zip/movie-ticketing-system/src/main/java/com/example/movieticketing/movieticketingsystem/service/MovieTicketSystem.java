package com.example.movieticketing.movieticketingsystem.service;

import java.util.List;

import com.example.movieticketing.movieticketingsystem.models.Movie;
import com.example.movieticketing.movieticketingsystem.models.Threater;
import com.example.movieticketing.movieticketingsystem.models.Ticket;
import com.example.movieticketing.movieticketingsystem.models.User;

public class MovieTicketSystem {
	
	List<Threater> threaters;
	
	private static volatile MovieTicketSystem instance;
	
	private static MovieTicketSystem getInstance() {
		
		//use of singleton pattern 
		
		//return instance after null check for instance;
	}
	
	//add threaters
	
	public void addThreater(Threater threater) {
		//
	}
	
	//searchMovie functionality 
	public List<Movie> searchMovie(String movieName){
		return null;
		
		///return List of movies 
	}
	
	public Ticket purchaseTicket(User user, Movie movie, String ticketType) {
		return null;
		
		// return new purachased ticket
		
	}
}

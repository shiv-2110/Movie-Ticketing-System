package com.example.movieticketing.movieticketingsystem.models;

public class Ticket {

	Movie movie;
	String type;
	double price;
	
	public Ticket(Movie movie, String type, double price) {
		super();
		this.movie = movie;
		this.type = type;
		this.price = price;
	}
	
	private double calculatePrice() {
		return movie.ticketPrice;
	}
}

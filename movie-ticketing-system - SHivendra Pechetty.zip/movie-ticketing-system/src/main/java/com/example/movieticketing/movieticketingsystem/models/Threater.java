package com.example.movieticketing.movieticketingsystem.models;

import java.util.ArrayList;
import java.util.List;

public class Threater {
	String name;
	String location;
	List<Movie> movies;
	List<Showtime> showtimes;
	
	public Threater(String name, String location) {
		super();
		this.name = name;
		this.location = location;
		this.movies = new ArrayList<>();
		this.showtimes = new ArrayList<>();
	}
	
	public void addMovie(Movie movie) {
		
		movies.add(movie);
	}
	
public void addShowtime(Showtime showtime) {
		
	showtimes.add(showtime);
	}

}

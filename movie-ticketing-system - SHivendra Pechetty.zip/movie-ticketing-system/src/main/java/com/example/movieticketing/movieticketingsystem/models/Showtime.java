package com.example.movieticketing.movieticketingsystem.models;

public class Showtime {
	
	Movie movie;
	String time;
	int screenNumber;
	
	public Showtime(Movie movie, String time, int screenNumber) {
		super();
		this.movie = movie;
		this.time = time;
		this.screenNumber = screenNumber;
	}
	
	
	

	

}

package com.example.movieticketing.movieticketingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieTicketingSystemApplication {

	public static void main(String[] args) {
		
		// Consider this as a normal Java program.
		
		//Create instances of movie and threater and showtime and user
		
		//Search for a movie
		List<Movie> searchResults = ticketSystem.searchMovie("TIGER");
		
		//Purchase Movie tickets
		
		
		SpringApplication.run(MovieTicketingSystemApplication.class, args);
	}

}

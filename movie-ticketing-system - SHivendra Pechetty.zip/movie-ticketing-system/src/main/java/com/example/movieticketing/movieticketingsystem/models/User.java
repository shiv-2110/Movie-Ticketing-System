package com.example.movieticketing.movieticketingsystem.models;

public class User {
	
	String name;
	String location;
	
	public User(String name, String location) {
		super();
		this.name = name;
		this.location = location;
	}
	
	

}
